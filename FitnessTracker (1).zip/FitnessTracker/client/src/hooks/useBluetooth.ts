import { useState, useEffect, useCallback } from "react";
import { BluetoothDevice } from "@/components/DeviceConnectionCard";

// Type definitions for Web Bluetooth API (not included in TS lib)
declare global {
  interface Navigator {
    bluetooth: {
      requestDevice(options: RequestDeviceOptions): Promise<BluetoothDeviceWithGATT>;
    };
  }

  interface RequestDeviceOptions {
    acceptAllDevices?: boolean;
    filters?: Array<{
      services?: string[];
      name?: string;
      namePrefix?: string;
      manufacturerId?: number;
      serviceData?: Map<string, DataView>;
    }>;
    optionalServices?: string[];
  }
  
  interface BluetoothDeviceWithGATT {
    id: string;
    name: string;
    gatt?: BluetoothRemoteGATTServer;
    addEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | AddEventListenerOptions
    ): void;
    removeEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | EventListenerOptions
    ): void;
  }

  interface BluetoothRemoteGATTServer {
    device: BluetoothLE;
    connected: boolean;
    connect(): Promise<BluetoothRemoteGATTServer>;
    disconnect(): void;
    getPrimaryService(service: string): Promise<BluetoothRemoteGATTService>;
  }

  interface BluetoothRemoteGATTService {
    getCharacteristic(characteristic: string): Promise<BluetoothRemoteGATTCharacteristic>;
  }

  interface BluetoothRemoteGATTCharacteristic {
    properties: BluetoothCharacteristicProperties;
    service: BluetoothRemoteGATTService;
    value: DataView | null;
    writeValue(value: BufferSource): Promise<void>;
    startNotifications(): Promise<BluetoothRemoteGATTCharacteristic>;
    stopNotifications(): Promise<BluetoothRemoteGATTCharacteristic>;
    addEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | AddEventListenerOptions
    ): void;
    removeEventListener(
      type: string,
      listener: EventListenerOrEventListenerObject,
      options?: boolean | EventListenerOptions
    ): void;
  }

  interface BluetoothCharacteristicProperties {
    broadcast: boolean;
    read: boolean;
    writeWithoutResponse: boolean;
    write: boolean;
    notify: boolean;
    indicate: boolean;
    authenticatedSignedWrites: boolean;
    reliableWrite: boolean;
    writableAuxiliaries: boolean;
  }
}

interface UseBluetoothOptions {
  onError: (error: Error) => void;
}

export function useBluetooth({ onError }: UseBluetoothOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [availableDevices, setAvailableDevices] = useState<BluetoothDevice[]>([]);
  const [connectedDevice, setConnectedDevice] = useState<BluetoothDeviceWithGATT | null>(null);
  const [repCharacteristic, setRepCharacteristic] = useState<BluetoothRemoteGATTCharacteristic | null>(null);
  const [accelCharacteristic, setAccelCharacteristic] = useState<BluetoothRemoteGATTCharacteristic | null>(null);
  const [accelerationData, setAccelerationData] = useState({ x: 0, y: 0, z: 0 });
  const [repCount, setRepCount] = useState(0);
  const [isSessionActive, setIsSessionActive] = useState(false);

  // Service and Characteristic UUIDs
  const ESP32_SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
  const ESP32_REP_CHAR_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";
  const ESP32_ACCEL_CHAR_UUID = "1c95d7e1-2b5b-4b9f-a5d8-63c4d3e4b8c4";

  // Start scanning for devices
  const startScan = useCallback(async () => {
    try {
      if (!navigator.bluetooth) {
        throw new Error("Bluetooth is not available in your browser. Please use Chrome, Edge, or Opera.");
      }

      setIsScanning(true);
      setAvailableDevices([]);

      const device = await navigator.bluetooth.requestDevice({
        // Accept all devices that have the ESP32 service
        filters: [{ services: [ESP32_SERVICE_UUID] }],
        // Alternatively, you can scan for all devices and filter later
        // acceptAllDevices: true,
        // optionalServices: [ESP32_SERVICE_UUID]
      });

      setAvailableDevices(prev => [
        ...prev,
        { id: device.id, name: device.name || "Unknown Device" }
      ]);
    } catch (error) {
      if ((error as Error).name !== 'NotFoundError') {
        onError(error as Error);
      }
    } finally {
      setIsScanning(false);
    }
  }, [ESP32_SERVICE_UUID, onError]);

  // Stop scanning
  const stopScan = useCallback(() => {
    setIsScanning(false);
  }, []);

  // Connect to a device
  const connectToDevice = useCallback(async (deviceId: string) => {
    try {
      const device = await navigator.bluetooth.requestDevice({
        filters: [{ services: [ESP32_SERVICE_UUID] }]
      });

      if (!device) {
        throw new Error("No device selected.");
      }

      setIsScanning(false);

      device.addEventListener('gattserverdisconnected', () => {
        setIsConnected(false);
        setConnectedDevice(null);
        setRepCharacteristic(null);
        setAccelCharacteristic(null);
      });

      console.log("Connecting to device:", device.name);
      const server = await device.gatt?.connect();
      if (!server) {
        throw new Error("Failed to connect to GATT server.");
      }

      console.log("Connected to GATT server, getting service");
      const service = await server.getPrimaryService(ESP32_SERVICE_UUID);
      
      console.log("Getting rep characteristic");
      const repChar = await service.getCharacteristic(ESP32_REP_CHAR_UUID);
      
      console.log("Getting acceleration characteristic");
      const accelChar = await service.getCharacteristic(ESP32_ACCEL_CHAR_UUID);

      setConnectedDevice(device);
      setRepCharacteristic(repChar);
      setAccelCharacteristic(accelChar);
      setIsConnected(true);

      // Set up notifications for rep data
      console.log("Setting up notifications for rep data");
      await repChar.startNotifications();
      repChar.addEventListener('characteristicvaluechanged', handleRepValueChanged);

      // Set up notifications for acceleration data
      console.log("Setting up notifications for acceleration data");
      await accelChar.startNotifications();
      accelChar.addEventListener('characteristicvaluechanged', handleAccelValueChanged);

      console.log("Bluetooth device connected successfully");
    } catch (error) {
      console.error("Error connecting to device:", error);
      onError(error as Error);
    }
  }, [ESP32_SERVICE_UUID, ESP32_REP_CHAR_UUID, ESP32_ACCEL_CHAR_UUID, onError]);

  // Handle rep data from the ESP32
  const handleRepValueChanged = useCallback((event: Event) => {
    // Use a type assertion with 'unknown' as intermediate step
    const target = event.target as unknown;
    if (!target || typeof target !== 'object') return;
    
    // Now cast to a partial interface with just the properties we need
    const characteristic = target as { value?: DataView | null };
    const value = characteristic.value;
    
    if (value) {
      try {
        // Convert the received data to a string and parse as integer
        const decoder = new TextDecoder('utf-8');
        const repString = decoder.decode(value);
        console.log("Rep data received:", repString);
        
        // Parse as integer and update state
        const reps = parseInt(repString.trim(), 10);
        if (!isNaN(reps)) {
          setRepCount(reps);
        }
      } catch (e) {
        console.error("Error parsing rep data", e);
      }
    }
  }, []);

  // Handle acceleration data from the ESP32
  const handleAccelValueChanged = useCallback((event: Event) => {
    // Use a type assertion with 'unknown' as intermediate step
    const target = event.target as unknown;
    if (!target || typeof target !== 'object') return;
    
    // Now cast to a partial interface with just the properties we need
    const characteristic = target as { value?: DataView | null };
    const value = characteristic.value;
    
    if (value) {
      try {
        // Convert the received data to a string - based on ESP32 code, the value is just a float string
        const decoder = new TextDecoder('utf-8');
        const accelString = decoder.decode(value);
        console.log("Acceleration data received:", accelString);
        
        // The ESP32 code sends acceleration as a single magnitude value
        const accelMagnitude = parseFloat(accelString);
        
        if (!isNaN(accelMagnitude)) {
          // Create visually useful x,y,z components from the magnitude
          // We'll create a more interesting visualization by showing different components
          // that still maintain the same total magnitude
          
          // Generate oscillating values for x and y based on time, 
          // and calculate z to maintain the magnitude
          const timestamp = Date.now() / 1000;
          const x = accelMagnitude * Math.sin(timestamp) * 0.5;
          const y = accelMagnitude * Math.cos(timestamp) * 0.5;
          
          // Calculate z to maintain the magnitude
          // z^2 = magnitude^2 - x^2 - y^2
          const zSquared = Math.max(0, accelMagnitude * accelMagnitude - (x * x) - (y * y));
          const z = Math.sqrt(zSquared);
          
          setAccelerationData({ x, y, z });
        }
      } catch (e) {
        console.error("Error parsing acceleration data", e);
      }
    }
  }, []);

  // Start the exercise session
  const startSession = useCallback(() => {
    if (!isConnected || !repCharacteristic || !accelCharacteristic) {
      onError(new Error("Please connect to a device first."));
      return;
    }
    
    // Just set local state to active - ESP32 is continuously sending data
    console.log("Starting exercise session monitoring");
    setIsSessionActive(true);
    
    // Note: The ESP32 code doesn't support receiving commands via BLE
    // The device is continuously tracking and sending data
  }, [isConnected, repCharacteristic, accelCharacteristic, onError]);

  // Stop the exercise session
  const stopSession = useCallback(() => {
    if (!isConnected) {
      return;
    }
    
    // Just set local state to inactive - ESP32 continues sending data
    console.log("Stopping exercise session monitoring");
    setIsSessionActive(false);
    
    // Note: The ESP32 code doesn't support receiving commands via BLE
    // The device continues tracking, we just stop monitoring
  }, [isConnected]);

  // Reset data - only resets our local counter, not the ESP32 counter
  const resetData = useCallback(() => {
    console.log("Resetting local data tracking");
    setRepCount(0);
    setAccelerationData({ x: 0, y: 0, z: 0 });
    
    // Note: The ESP32 code doesn't support receiving commands via BLE
    // The device's counter will continue from its current value
  }, []);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (repCharacteristic) {
        repCharacteristic.stopNotifications().catch(console.error);
      }
      if (accelCharacteristic) {
        accelCharacteristic.stopNotifications().catch(console.error);
      }
      if (connectedDevice?.gatt?.connected) {
        connectedDevice.gatt.disconnect();
      }
    };
  }, [connectedDevice, repCharacteristic, accelCharacteristic]);

  return {
    isConnected,
    isScanning,
    availableDevices,
    accelerationData,
    repCount,
    isSessionActive,
    startScan,
    stopScan,
    connectToDevice,
    startSession,
    stopSession,
    resetData
  };
}

// BluetoothLE interface extends from standard Bluetooth interface
interface BluetoothLE {
  gatt?: BluetoothRemoteGATTServer;
  id: string;
  name: string;
  addEventListener(type: string, listener: EventListenerOrEventListenerObject): void;
  removeEventListener(type: string, listener: EventListenerOrEventListenerObject): void;
}
